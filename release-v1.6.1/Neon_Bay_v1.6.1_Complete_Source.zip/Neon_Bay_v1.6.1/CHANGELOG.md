# Changelog

## 1.3.0 — Living City

- Added route-driven traffic, signals and dynamic density.
- Added pedestrian routines and witness reporting.
- Reworked police response into three wanted stages with arrests and roadblocks.
- Added engine/body/tire damage and performance penalties.
- Added taxi and street-race activities.
- Added persistent reputation, career statistics and garage upgrades.
- Added useful apartment and garage interactions.
- Added v3 save migration, new HUD panels and v1.3 trailer mode.

## 1.2.0 — Coastline Reborn

- Added an original animated GLB character asset with Idle, Walk, Run, Aim, Shoot, Talk and Cower clips.
- Replaced player and NPC block figures with reusable GLB actor controllers and role-specific palettes.
- Added voiced First Ride dialogue with subtitles and a cinematic camera sequence.
- Added four playable interiors: apartment, gun shop, garage workshop and police station lobby.
- Added vehicle smoke, sparks, dents, cracked glass, brake lights and repairable bodywork.
- Added pistol/shotgun switching, separate ammunition, shotgun spread, recoil and weapon-specific reloads.
- Added enemy alert, search and cover states plus animated civilian reactions to nearby gunfire.
- Redesigned Ocean Drive with the Mirage Hotel, Moonlight Diner, Pixel Palace Arcade, neon arches and street props.
- Added a two-minute in-engine trailer mode and a dedicated trailer page.
- Added Electron packaging and a Windows portable-build GitHub Actions workflow.
- Upgraded saves to schema version 2 with automatic migration from version 1.

## 1.0.0 — Chapter One

- Initial five-mission browser game.
