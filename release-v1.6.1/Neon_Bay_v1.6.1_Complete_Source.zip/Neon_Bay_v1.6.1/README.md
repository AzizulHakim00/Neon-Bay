# Neon Bay v1.3 — Living City

**Neon Bay** is an original browser-based 3D open-city action game built with Three.js, modular JavaScript and Vite. Chapter One contains five connected story missions, driving, combat, police pursuit, useful interiors, side activities, saving, dynamic weather and desktop/mobile controls.

Version 1.3 turns the Coastline District into a more reactive city: traffic follows road routes and signals, civilians follow daily routines and report crimes, police escalate through three response stages, vehicle damage affects performance, and taxi/racing work feeds a persistent reputation system.

## v1.3 highlights

- Ten route-driven traffic vehicles with lane routes, intersection signals, vehicle spacing and time/weather density
- Scheduled pedestrians with sidewalk routines, social/vendor roles, fleeing and witness reporting
- Three-stage wanted system: investigation, pursuit and lockdown
- Police cruisers, search zones, roadblocks, spike-strip tire damage and arrest/fine outcomes
- Engine, body and tire damage with smoke, sparks, cracked glass, broken lights and critical fire
- Useful apartment services: saving, wardrobe changes and career statistics
- Useful garage services: repairs plus engine, brake and grip upgrades
- Coastline Taxi side jobs and Ocean Drive street races
- Six reputation ranks from Unknown to Neon Legend
- Persistent v3 save data for reputation, statistics, upgrades, outfit and story progress
- Updated HUD for reputation, side activities, wanted status and vehicle diagnostics
- In-engine v1.3 trailer mode

## Story missions

1. **First Ride** — meet Mara, take the Sunset GT and deliver it to the Coastline garage.
2. **Beach Exchange** — survive an ambush, attract police attention and escape to the marina.
3. **Hot Delivery** — secure a package and beat a timed pursuit to the safehouse.
4. **Warehouse Trouble** — clear a warehouse yard, recover a ledger and return it safely.
5. **District Boss** — defeat the boss and guards, then escape across the pier.

## Side activities

### Coastline Taxi

Take the yellow taxi, collect a passenger and deliver them across the city before the timer expires. Completed fares award cash, reputation and career statistics.

### Ocean Drive Sprint

Enter a vehicle at the race marker and pass every checkpoint before time runs out. Better garage upgrades improve acceleration, braking and grip.

## Wanted response

| Level | Response |
|---|---|
| ★ | Investigation: nearby officers and one patrol cruiser |
| ★★ | Pursuit: more officers, cruisers and roadblocks |
| ★★★ | Lockdown: maximum response, repeated roadblocks and spike strips |

Remain close to police while stopped and the arrest meter completes. Arrest removes the wanted level, applies a cash fine and returns the player near the police station.

## Reputation ranks

- Unknown
- Street Runner
- Trusted Driver
- Bay Operator
- District Power
- Neon Legend

Story missions, taxi fares, race victories and police escapes increase reputation.

## Controls

| Action | Control |
|---|---|
| Move / drive | `W A S D` |
| Look / aim | Mouse |
| Sprint / vehicle boost | `Shift` |
| Jump / handbrake | `Space` |
| Enter, exit or interact | `E` |
| Shoot | Left mouse button |
| Reload | `R` |
| Select pistol / shotgun | `1` / `2` |
| Cycle weapon | `Q` |
| Pause | `Esc` |

Touch controls include movement, camera look, fire, jump, interaction and weapon swapping.

## Run locally

Node.js 20 or newer is required. Node.js 22 is recommended.

```bash
npm install
npm run dev
```

Open the URL shown by Vite, normally `http://localhost:5173`.

## Validate and build

```bash
npm test
```

The complete validation suite runs:

- JavaScript syntax validation
- Animated GLB, interior and vehicle-damage module tests
- Living-city route, traffic-light, wanted and progression tests
- Menu, save, weapon, interior, taxi, wanted and pause smoke tests
- All five story mission flows
- Nine collision-reachability checks
- Production Vite build

The deployable website is generated in `dist/`.

## Source architecture

```text
src/
├── main.js
├── styles.css
├── assets/
│   └── neon-citizen-data.js
└── modules/
    ├── actor-system.js
    ├── demo-director.js
    ├── dialogue-system.js
    ├── interior-system.js
    ├── living-city.js
    └── vehicle-damage.js
scripts/
├── living-city-test.mjs
├── mission-test.mjs
├── module-test.mjs
├── smoke-test.mjs
└── test-harness.mjs
```

## Deployment

The included Vercel configuration runs the Vite production build and publishes `dist`. Pushes to `main` automatically trigger a new Vercel deployment.

GitHub Pages and Netlify configurations are also included.

## Legal and scope

All characters, branding, missions, low-poly artwork and synthesized/browser audio are original to this project. The game takes inspiration from the general open-world action genre but does not use copied GTA maps, characters, music, logos, dialogue or proprietary assets.

Neon Bay is a polished browser-game vertical slice, not a commercial GTA-sized production. The roadmap intentionally prioritizes a dense, reactive city over a very large empty map.
